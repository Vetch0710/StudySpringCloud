create definer = root@localhost trigger addSeat
    after insert
    on cinema_order
    for each row
    UPDATE Cinema_seat
SET seat_num =  CONCAT(seat_num,CONCAT(',',new.order_seat))
WHERE arrangement_id = new.arrangement_id;

