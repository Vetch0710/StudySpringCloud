create definer = root@localhost trigger addSeats
    after insert
    on cinema_arrangement
    for each row
    INSERT INTO Cinema_seat(arrangement_id,seat_num) VALUE(new.arrangement_id,'');

