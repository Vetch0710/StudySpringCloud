create definer = root@localhost trigger delSeat
    after delete
    on cinema_order
    for each row
    UPDATE Cinema_seat
SET seat_num = REPLACE(seat_num,CONCAT(',',old.order_seat),'')
WHERE arrangement_id = old.arrangement_id;

