create definer = root@localhost trigger add_wants_num
    after insert
    on movie_wants
    for each row
    UPDATE Cinema_movie
SET wants_num = wants_num + 1
WHERE movie_id = new.movie_id
;

