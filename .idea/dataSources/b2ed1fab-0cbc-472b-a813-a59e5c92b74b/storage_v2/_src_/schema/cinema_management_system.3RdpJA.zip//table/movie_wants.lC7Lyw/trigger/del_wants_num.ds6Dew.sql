create definer = root@localhost trigger del_wants_num
    after delete
    on movie_wants
    for each row
    UPDATE Cinema_movie
SET wants_num = wants_num - 1
WHERE movie_id = old.movie_id
;

