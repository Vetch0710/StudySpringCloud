create definer = root@localhost trigger delSeats
    after delete
    on cinema_arrangement
    for each row
    DELETE FROM Cinema_seat
WHERE arrangement_id = old.arrangement_id
;

